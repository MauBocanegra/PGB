package propulsar.qroo.DomainLayer.Services;

/**
 * Created by maubocanegra on 28/03/17.
 */

public class NotificationSettings {

    public static String SenderId = "718228527870";
    //public static String SenderId = "955555330027";
    //public static String SenderId = "601242410454";
    //public static String SenderId = "firebase-yonayarit";
    public static String HubName = "QRoo_NotificationHub";
    public static String HubListenConnectionString = "Endpoint=sb://qroonotificationhubnamespace.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=2E5gYxTuNTr0DQandBghn540jAEBNGGYbo4IuHSz+YY=";
    //public static String HubListenConnectionString = "sb://yonayaritnamespace.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=0sesO6Cvp7CwifSgZGhR9FIqhzi4s+nWBF03I4XSXmg=";
    //public static String HubFullAccess = "sb://yonayaritnamespace.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=oro2LAoTtzLtX9Vta9uQvJJRPs1Efd6wZc8XshdWpVk=";
}
