package propulsar.qroo.DomainLayer.Objects;

/**
 * Created by maubocanegra on 09/03/17.
 */

public class OwnMsg extends Msg {
    public OwnMsg(){}
}
