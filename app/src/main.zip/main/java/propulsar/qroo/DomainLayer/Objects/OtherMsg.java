package propulsar.qroo.DomainLayer.Objects;

/**
 * Created by maubocanegra on 09/03/17.
 */

public class OtherMsg extends Msg {
    public OtherMsg(){}
}
